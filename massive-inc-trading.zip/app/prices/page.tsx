"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PriceChart } from "@/components/prices/price-chart"
import { PriceAlerts } from "@/components/prices/price-alerts"
import { Building2, TrendingUp, TrendingDown, RefreshCw, Clock, AlertCircle } from "lucide-react"
import Link from "next/link"

interface MetalPrice {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  high: number
  low: number
  volume: number
  lastUpdated: string
  unit: string
}

export default function PricesPage() {
  const [prices, setPrices] = useState<MetalPrice[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [selectedTimeframe, setSelectedTimeframe] = useState("1D")

  // Simulate real-time price updates
  useEffect(() => {
    const generatePrices = (): MetalPrice[] => {
      const baseData = [
        { symbol: "CU", name: "Copper", basePrice: 8245, unit: "USD/MT" },
        { symbol: "AL", name: "Aluminum", basePrice: 2156, unit: "USD/MT" },
        { symbol: "ZN", name: "Zinc", basePrice: 2890, unit: "USD/MT" },
        { symbol: "NI", name: "Nickel", basePrice: 18450, unit: "USD/MT" },
        { symbol: "PB", name: "Lead", basePrice: 2034, unit: "USD/MT" },
        { symbol: "SN", name: "Tin", basePrice: 25670, unit: "USD/MT" },
        { symbol: "FE", name: "Iron Ore", basePrice: 145, unit: "USD/MT" },
        { symbol: "ST", name: "Steel Rebar", basePrice: 650, unit: "USD/MT" },
      ]

      return baseData.map((metal) => {
        const changePercent = (Math.random() - 0.5) * 6 // -3% to +3%
        const change = (metal.basePrice * changePercent) / 100
        const currentPrice = metal.basePrice + change
        const high = currentPrice + Math.random() * 50
        const low = currentPrice - Math.random() * 50

        return {
          symbol: metal.symbol,
          name: metal.name,
          price: Math.round(currentPrice * 100) / 100,
          change: Math.round(change * 100) / 100,
          changePercent: Math.round(changePercent * 100) / 100,
          high: Math.round(high * 100) / 100,
          low: Math.round(low * 100) / 100,
          volume: Math.floor(Math.random() * 10000) + 1000,
          lastUpdated: new Date().toISOString(),
          unit: metal.unit,
        }
      })
    }

    const updatePrices = () => {
      setPrices(generatePrices())
      setLastUpdate(new Date())
      setIsLoading(false)
    }

    // Initial load
    updatePrices()

    // Update every 30 seconds
    const interval = setInterval(updatePrices, 30000)

    return () => clearInterval(interval)
  }, [])

  const refreshPrices = () => {
    setIsLoading(true)
    setTimeout(() => {
      const newPrices = prices.map((price) => {
        const changePercent = (Math.random() - 0.5) * 2 // Smaller changes for refresh
        const change = (price.price * changePercent) / 100
        return {
          ...price,
          price: Math.round((price.price + change) * 100) / 100,
          change: Math.round((price.change + change) * 100) / 100,
          changePercent: Math.round((price.changePercent + changePercent) * 100) / 100,
          lastUpdated: new Date().toISOString(),
        }
      })
      setPrices(newPrices)
      setLastUpdate(new Date())
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-3">
              <Building2 className="h-8 w-8 text-cyan-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">MASSIVE INC</h1>
                <p className="text-sm text-gray-600">LME Prices</p>
              </div>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
              </div>
              <Button variant="outline" onClick={refreshPrices} disabled={isLoading}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Link href="/marketplace">
                <Button className="bg-cyan-600 hover:bg-cyan-700">Go to Marketplace</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">London Metal Exchange Prices</h1>
          <p className="text-lg text-gray-600">
            Real-time pricing data for major metals and commodities traded on the LME
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="charts">Charts</TabsTrigger>
            <TabsTrigger value="alerts">Price Alerts</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Market Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Market Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium">Open</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Gainers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    {prices.filter((p) => p.changePercent > 0).length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Losers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">
                    {prices.filter((p) => p.changePercent < 0).length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Volume</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-gray-900">
                    {prices.reduce((sum, p) => sum + p.volume, 0).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Price Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {prices.map((metal) => (
                <Card key={metal.symbol} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{metal.name}</CardTitle>
                        <CardDescription className="text-xs">{metal.symbol}</CardDescription>
                      </div>
                      <div className="flex items-center">
                        {metal.changePercent >= 0 ? (
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-2xl font-bold text-gray-900">${metal.price.toLocaleString()}</div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={metal.changePercent >= 0 ? "default" : "destructive"} className="text-xs">
                          {metal.changePercent >= 0 ? "+" : ""}
                          {metal.changePercent}%
                        </Badge>
                        <span className={`text-sm ${metal.changePercent >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {metal.change >= 0 ? "+" : ""}${metal.change}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 space-y-1">
                        <div>High: ${metal.high.toLocaleString()}</div>
                        <div>Low: ${metal.low.toLocaleString()}</div>
                        <div>Volume: {metal.volume.toLocaleString()}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="charts" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Price Charts</h2>
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1D">1 Day</SelectItem>
                  <SelectItem value="1W">1 Week</SelectItem>
                  <SelectItem value="1M">1 Month</SelectItem>
                  <SelectItem value="3M">3 Months</SelectItem>
                  <SelectItem value="1Y">1 Year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {prices.slice(0, 4).map((metal) => (
                <Card key={metal.symbol}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>
                        {metal.name} ({metal.symbol})
                      </span>
                      <Badge variant={metal.changePercent >= 0 ? "default" : "destructive"}>
                        {metal.changePercent >= 0 ? "+" : ""}
                        {metal.changePercent}%
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      Current: ${metal.price.toLocaleString()} {metal.unit}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <PriceChart metal={metal} timeframe={selectedTimeframe} />
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="alerts">
            <PriceAlerts metals={prices} />
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Analysis</CardTitle>
                <CardDescription>Latest insights and trends in the metals market</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Top Performers</h3>
                    <div className="space-y-2">
                      {prices
                        .sort((a, b) => b.changePercent - a.changePercent)
                        .slice(0, 3)
                        .map((metal) => (
                          <div key={metal.symbol} className="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span className="font-medium">{metal.name}</span>
                            <Badge variant="default">+{metal.changePercent}%</Badge>
                          </div>
                        ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Biggest Declines</h3>
                    <div className="space-y-2">
                      {prices
                        .sort((a, b) => a.changePercent - b.changePercent)
                        .slice(0, 3)
                        .map((metal) => (
                          <div key={metal.symbol} className="flex justify-between items-center p-2 bg-red-50 rounded">
                            <span className="font-medium">{metal.name}</span>
                            <Badge variant="destructive">{metal.changePercent}%</Badge>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="text-lg font-semibold mb-3">Market Commentary</h3>
                  <div className="prose text-gray-600">
                    <p>
                      Today's trading session shows mixed sentiment across base metals, with copper leading gains on
                      strong demand from the construction sector. Industrial metals continue to be supported by
                      infrastructure spending and supply chain improvements.
                    </p>
                    <p>
                      Aluminum prices remain volatile due to energy cost concerns, while zinc shows resilience backed by
                      steady industrial demand. Traders should monitor global economic indicators and supply disruptions
                      for potential market movements.
                    </p>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-yellow-800">Market Alert</h4>
                      <p className="text-sm text-yellow-700 mt-1">
                        High volatility expected due to upcoming economic data releases. Consider risk management
                        strategies for active positions.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
