import { NextResponse } from "next/server"

// Simulate LME price data
const generatePriceData = () => {
  const baseData = [
    { symbol: "CU", name: "Copper", basePrice: 8245, unit: "USD/MT" },
    { symbol: "AL", name: "Aluminum", basePrice: 2156, unit: "USD/MT" },
    { symbol: "ZN", name: "Zinc", basePrice: 2890, unit: "USD/MT" },
    { symbol: "NI", name: "Nickel", basePrice: 18450, unit: "USD/MT" },
    { symbol: "PB", name: "Lead", basePrice: 2034, unit: "USD/MT" },
    { symbol: "SN", name: "Tin", basePrice: 25670, unit: "USD/MT" },
    { symbol: "FE", name: "Iron Ore", basePrice: 145, unit: "USD/MT" },
    { symbol: "ST", name: "Steel Rebar", basePrice: 650, unit: "USD/MT" },
    ]

  return baseData.map((metal) => {
    const changePercent = (Math.random() - 0.5) * 6 // -3% to +3%
    const change = (metal.basePrice * changePercent) / 100
    const currentPrice = metal.basePrice + change
    const high = currentPrice + Math.random() * 50
    const low = currentPrice - Math.random() * 50

    return {
      symbol: metal.symbol,
      name: metal.name,
      price: Math.round(currentPrice * 100) / 100,
      change: Math.round(change * 100) / 100,
      changePercent: Math.round(changePercent * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      volume: Math.floor(Math.random() * 10000) + 1000,
      lastUpdated: new Date().toISOString(),
      unit: metal.unit,
    }
  })
}

export async function GET() {
  try {
    const prices = generatePriceData()
    return NextResponse.json({ prices, timestamp: new Date().toISOString() })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch prices" }, { status: 500 })
  }
}
