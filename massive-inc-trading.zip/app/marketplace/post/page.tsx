import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PostTradeForm } from "@/components/marketplace/post-trade-form"
import { Building2, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function PostTradePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-3">
              <Building2 className="h-8 w-8 text-cyan-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">MASSIVE INC</h1>
                <p className="text-sm text-gray-600">Post Trade</p>
              </div>
            </Link>
            <Link href="/marketplace">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Marketplace
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Post a Trade</h1>
          <p className="text-lg text-gray-600">Create a new buying or selling opportunity in the marketplace</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Trade Details</CardTitle>
            <CardDescription>
              Fill in the details of your trade. All posts are subject to verification by MASSIVE INC.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PostTradeForm />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
