"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TradeFilters } from "@/components/marketplace/trade-filters"
import { Building2, Plus, Search, MapPin, Calendar, Phone, Mail } from "lucide-react"
import Link from "next/link"

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState({})

  const sampleTrades = [
    {
      id: 1,
      type: "BUYING",
      commodity: "Copper Cathodes",
      quantity: "500",
      unit: "MT",
      price: "8200",
      priceUnit: "USD/MT",
      company: "Global Metals Ltd",
      location: "Mumbai, India",
      posted: "2 hours ago",
      description: "Looking for Grade A copper cathodes, 99.99% purity. Long-term contract preferred.",
      contactEmail: "buyer@globalmetals.com",
      contactPhone: "+91 98765 43210",
      validUntil: "2024-02-15",
    },
    {
      id: 2,
      type: "SELLING",
      commodity: "Steel Billets",
      quantity: "1000",
      unit: "MT",
      price: "650",
      priceUnit: "USD/MT",
      company: "Steel Works Inc",
      location: "Chennai, India",
      posted: "4 hours ago",
      description: "High quality steel billets, ready for immediate delivery. FOB Chennai port.",
      contactEmail: "sales@steelworks.com",
      contactPhone: "+91 98765 43211",
      validUntil: "2024-02-20",
    },
    {
      id: 3,
      type: "BUYING",
      commodity: "Aluminum Ingots",
      quantity: "200",
      unit: "MT",
      price: "2150",
      priceUnit: "USD/MT",
      company: "Metro Trading Co",
      location: "Delhi, India",
      posted: "6 hours ago",
      description: "Seeking aluminum ingots for manufacturing. Regular monthly requirement.",
      contactEmail: "procurement@metrotrading.com",
      contactPhone: "+91 98765 43212",
      validUntil: "2024-02-10",
    },
    {
      id: 4,
      type: "SELLING",
      commodity: "Zinc Concentrate",
      quantity: "300",
      unit: "MT",
      price: "2800",
      priceUnit: "USD/MT",
      company: "Mining Solutions",
      location: "Kolkata, India",
      posted: "8 hours ago",
      description: "Premium zinc concentrate, 55% Zn content. Direct from mine.",
      contactEmail: "export@miningsolutions.com",
      contactPhone: "+91 98765 43213",
      validUntil: "2024-02-25",
    },
    {
      id: 5,
      type: "BUYING",
      commodity: "Chemicals",
      quantity: "50",
      unit: "MT",
      price: "1200",
      priceUnit: "USD/MT",
      company: "Chemical Industries Ltd",
      location: "Pune, India",
      posted: "12 hours ago",
      description: "Industrial grade chemicals for pharmaceutical manufacturing.",
      contactEmail: "purchase@chemind.com",
      contactPhone: "+91 98765 43214",
      validUntil: "2024-02-18",
    },
    {
      id: 6,
      type: "SELLING",
      commodity: "Plastic Raw Materials",
      quantity: "100",
      unit: "MT",
      price: "1800",
      priceUnit: "USD/MT",
      company: "Polymer Corp",
      location: "Bangalore, India",
      posted: "1 day ago",
      description: "High-grade polymer pellets, various grades available.",
      contactEmail: "sales@polymercorp.com",
      contactPhone: "+91 98765 43215",
      validUntil: "2024-03-01",
    },
  ]

  const filteredTrades = sampleTrades.filter((trade) => {
    const matchesSearch =
      searchQuery === "" ||
      trade.commodity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.location.toLowerCase().includes(searchQuery.toLowerCase())

    // Add filter logic here based on the filters state
    return matchesSearch
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-3">
              <Building2 className="h-8 w-8 text-cyan-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">MASSIVE INC</h1>
                <p className="text-sm text-gray-600">Trading Marketplace</p>
              </div>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/marketplace/post">
                <Button className="bg-cyan-600 hover:bg-cyan-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Post Trade
                </Button>
              </Link>
              <Button variant="outline">Sign Out</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Trading Marketplace</h1>
          <p className="text-lg text-gray-600">
            Welcome to the MASSIVE INC trading platform. Browse and post buying/selling opportunities.
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input
                    type="text"
                    placeholder="Search commodities, companies, or locations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                  />
                </div>
              </div>
              <TradeFilters onFiltersChange={setFilters} />
            </div>
          </div>
        </div>

        {/* Results Summary */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredTrades.length} trade{filteredTrades.length !== 1 ? "s" : ""}
            {searchQuery && ` for "${searchQuery}"`}
          </p>
        </div>

        {/* Trading Posts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredTrades.map((trade) => (
            <Card key={trade.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant={trade.type === "BUYING" ? "default" : "secondary"}>{trade.type}</Badge>
                      <span className="text-sm text-gray-500">{trade.posted}</span>
                    </div>
                    <CardTitle className="text-xl mb-1">{trade.commodity}</CardTitle>
                    <CardDescription className="flex items-center">
                      <Building2 className="h-4 w-4 mr-1" />
                      {trade.company}
                    </CardDescription>
                    <CardDescription className="flex items-center mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      {trade.location}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Quantity</p>
                    <p className="font-semibold">
                      {trade.quantity} {trade.unit}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Price</p>
                    <p className="font-semibold text-green-600">
                      ${trade.price}/{trade.priceUnit.split("/")[1]}
                    </p>
                  </div>
                </div>

                {trade.description && (
                  <div className="mb-4">
                    <p className="text-sm text-gray-600 mb-1">Description</p>
                    <p className="text-sm text-gray-800">{trade.description}</p>
                  </div>
                )}

                <div className="space-y-2 mb-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    Valid until: {new Date(trade.validUntil).toLocaleDateString()}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <Button className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                    <Mail className="h-4 w-4 mr-2" />
                    Contact Trader
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button variant="outline" size="lg">
            Load More Posts
          </Button>
        </div>

        {/* No Results */}
        {filteredTrades.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No trades found matching your criteria.</p>
            <Link href="/marketplace/post">
              <Button className="mt-4 bg-cyan-600 hover:bg-cyan-700">Post the First Trade</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
