import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Page() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-cyan-600 to-cyan-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">Empowering Global Trade in Commodities</h1>
            <p className="text-xl mb-8 text-cyan-100 max-w-3xl mx-auto">
              Your trusted partner in metals, steel, chemicals, and pharmaceuticals. Connect with verified traders
              worldwide through our secure marketplace.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register">
                <Button size="lg" className="bg-white text-cyan-600 hover:bg-gray-100 px-8 py-3">
                  Explore Our Marketplace
                </Button>
              </Link>
              <Link href="/prices">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-cyan-600 px-8 py-3 bg-transparent"
                >
                  View LME Prices
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="text-center mt-8">
        <Link href="/prices">
          <Button className="bg-cyan-600 hover:bg-cyan-700">View All Prices</Button>
        </Link>
      </div>
    </>
  )
}
