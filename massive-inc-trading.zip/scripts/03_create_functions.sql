-- Utility functions for MASSIVE INC Trading Platform

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers to automatically update updated_at columns
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trade_posts_updated_at BEFORE UPDATE ON trade_posts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_admin_settings_updated_at BEFORE UPDATE ON admin_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to clean up expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM user_sessions WHERE expires_at < CURRENT_TIMESTAMP;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get active trade posts count by commodity
CREATE OR REPLACE FUNCTION get_active_trades_by_commodity()
RETURNS TABLE(commodity VARCHAR, buying_count BIGINT, selling_count BIGINT) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tp.commodity,
        COUNT(*) FILTER (WHERE tp.type = 'buying') as buying_count,
        COUNT(*) FILTER (WHERE tp.type = 'selling') as selling_count
    FROM trade_posts tp
    WHERE tp.status = 'approved' 
    AND (tp.valid_until IS NULL OR tp.valid_until >= CURRENT_DATE)
    GROUP BY tp.commodity
    ORDER BY tp.commodity;
END;
$$ LANGUAGE plpgsql;
