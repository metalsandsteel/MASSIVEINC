-- Seed data for MASSIVE INC Trading Platform

-- Insert admin settings
INSERT INTO admin_settings (setting_key, setting_value, description) VALUES
('platform_name', 'MASSIVE INC Trading Platform', 'Platform display name'),
('company_address', 'Chennai, Tamil Nadu, India', 'Company headquarters location'),
('contact_email', 'info@massiveinc.com', 'Primary contact email'),
('contact_phone', '+91-44-XXXX-XXXX', 'Primary contact phone'),
('auto_approve_users', 'false', 'Automatically approve new user registrations'),
('auto_approve_trades', 'false', 'Automatically approve new trade posts'),
('max_trade_validity_days', '90', 'Maximum validity period for trade posts'),
('supported_currencies', 'USD,EUR,INR,GBP,JPY', 'Supported currencies for trading')
ON CONFLICT (setting_key) DO NOTHING;

-- Insert sample LME price data
INSERT INTO lme_prices (metal, price, change_amount, change_percentage, high_52week, low_52week) VALUES
('Copper', 8245.50, 125.25, 1.54, 9500.00, 7800.00),
('Aluminium', 2156.75, -23.50, -1.08, 2400.00, 1950.00),
('Zinc', 2890.25, 45.75, 1.61, 3200.00, 2650.00),
('Lead', 2134.00, 12.25, 0.58, 2350.00, 1980.00),
('Tin', 28750.50, -150.25, -0.52, 32000.00, 26500.00),
('Nickel', 16890.75, 234.50, 1.41, 19500.00, 15200.00),
('Steel Rebar', 3456.25, 78.50, 2.32, 3800.00, 3100.00),
('Iron Ore', 112.45, -2.15, -1.88, 135.00, 95.50)
ON CONFLICT (metal, DATE(last_updated)) DO NOTHING;

-- Insert sample admin user (password should be hashed in real implementation)
INSERT INTO users (email, phone, password_hash, first_name, last_name, company_name, country, business_type, status) VALUES
('admin@massiveinc.com', '+91-44-1234-5678', '$2b$10$example_hash', 'Admin', 'User', 'MASSIVE INC', 'India', 'Trading Company', 'approved')
ON CONFLICT (email) DO NOTHING;
