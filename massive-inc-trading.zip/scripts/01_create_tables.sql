-- Create database tables for MASSIVE INC Trading Platform

-- Users table for storing user registration data
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    country VARCHAR(100) NOT NULL,
    business_type VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, suspended
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trade posts table for buying/selling listings
CREATE TABLE IF NOT EXISTS trade_posts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(10) NOT NULL, -- 'buying' or 'selling'
    commodity VARCHAR(100) NOT NULL,
    subcategory VARCHAR(100),
    quantity DECIMAL(15,2) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    price_per_unit DECIMAL(15,2),
    currency VARCHAR(10) DEFAULT 'USD',
    location VARCHAR(255) NOT NULL,
    description TEXT,
    specifications JSONB,
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    valid_until DATE,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected, expired
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- LME prices table for storing metal exchange data
CREATE TABLE IF NOT EXISTS lme_prices (
    id SERIAL PRIMARY KEY,
    metal VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'USD',
    unit VARCHAR(20) DEFAULT 'per tonne',
    change_amount DECIMAL(10,2),
    change_percentage DECIMAL(5,2),
    high_52week DECIMAL(10,2),
    low_52week DECIMAL(10,2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(metal, DATE(last_updated))
);

-- Admin settings table
CREATE TABLE IF NOT EXISTS admin_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User sessions table for authentication
CREATE TABLE IF NOT EXISTS user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_trade_posts_user_id ON trade_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_trade_posts_commodity ON trade_posts(commodity);
CREATE INDEX IF NOT EXISTS idx_trade_posts_type ON trade_posts(type);
CREATE INDEX IF NOT EXISTS idx_trade_posts_status ON trade_posts(status);
CREATE INDEX IF NOT EXISTS idx_lme_prices_metal ON lme_prices(metal);
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(session_token);
