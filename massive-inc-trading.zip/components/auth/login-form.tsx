"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Mail, Phone } from "lucide-react"
import { useRouter } from "next/navigation"

export function LoginForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [loginMethod, setLoginMethod] = useState<"email" | "phone">("email")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const formData = new FormData(e.currentTarget)
    const identifier = formData.get(loginMethod) as string
    const password = formData.get("password") as string

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // For demo purposes, accept any credentials
      if (identifier && password) {
        // Store user session (in a real app, this would be handled by your auth system)
        localStorage.setItem(
          "user",
          JSON.stringify({
            id: "1",
            [loginMethod]: identifier,
            name: "Demo User",
          }),
        )
        router.push("/marketplace")
      } else {
        setError("Please fill in all fields")
      }
    } catch (err) {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex space-x-2 mb-4">
        <Button
          type="button"
          variant={loginMethod === "email" ? "default" : "outline"}
          size="sm"
          onClick={() => setLoginMethod("email")}
          className="flex-1"
        >
          <Mail className="h-4 w-4 mr-2" />
          Email
        </Button>
        <Button
          type="button"
          variant={loginMethod === "phone" ? "default" : "outline"}
          size="sm"
          onClick={() => setLoginMethod("phone")}
          className="flex-1"
        >
          <Phone className="h-4 w-4 mr-2" />
          Phone
        </Button>
      </div>

      <div className="space-y-2">
        <Label htmlFor={loginMethod}>{loginMethod === "email" ? "Email Address" : "Phone Number"}</Label>
        <Input
          id={loginMethod}
          name={loginMethod}
          type={loginMethod === "email" ? "email" : "tel"}
          placeholder={loginMethod === "email" ? "Enter your email" : "Enter your phone number"}
          required
          disabled={isLoading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          name="password"
          type="password"
          placeholder="Enter your password"
          required
          disabled={isLoading}
        />
      </div>

      <Button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Signing in...
          </>
        ) : (
          "Sign In"
        )}
      </Button>

      <div className="text-center">
        <Button variant="link" className="text-sm text-cyan-600 hover:text-cyan-700">
          Forgot your password?
        </Button>
      </div>
    </form>
  )
}
