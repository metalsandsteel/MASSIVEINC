"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"

export function PostTradeForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  const commodities = [
    "Iron & Steel",
    "Copper",
    "Aluminum",
    "Zinc",
    "Nickel",
    "Lead",
    "Tin",
    "Metal Scraps",
    "Chemicals",
    "Pharmaceuticals",
    "Plastic Raw Materials",
    "Paper Products",
    "Industrial Machinery",
    "Other",
  ]

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const formData = new FormData(e.currentTarget)
    const tradeData = {
      tradeType: formData.get("tradeType") as string,
      commodity: formData.get("commodity") as string,
      customCommodity: formData.get("customCommodity") as string,
      quantity: formData.get("quantity") as string,
      unit: formData.get("unit") as string,
      price: formData.get("price") as string,
      priceUnit: formData.get("priceUnit") as string,
      location: formData.get("location") as string,
      description: formData.get("description") as string,
      contactEmail: formData.get("contactEmail") as string,
      contactPhone: formData.get("contactPhone") as string,
      validUntil: formData.get("validUntil") as string,
    }

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Validate required fields
      if (!tradeData.tradeType || !tradeData.commodity || !tradeData.quantity || !tradeData.price) {
        setError("Please fill in all required fields")
        return
      }

      setSuccess(true)
      setTimeout(() => {
        router.push("/marketplace")
      }, 2000)
    } catch (err) {
      setError("Failed to post trade. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  if (success) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <AlertDescription className="text-green-800">
          Trade posted successfully! Your post is now under review by MASSIVE INC and will be published once approved.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Trade Type */}
      <div className="space-y-3">
        <Label className="text-base font-medium">Trade Type *</Label>
        <RadioGroup name="tradeType" className="flex space-x-6">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="buying" id="buying" />
            <Label htmlFor="buying">Buying</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="selling" id="selling" />
            <Label htmlFor="selling">Selling</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Commodity */}
      <div className="space-y-2">
        <Label htmlFor="commodity">Commodity *</Label>
        <Select name="commodity" required>
          <SelectTrigger>
            <SelectValue placeholder="Select commodity" />
          </SelectTrigger>
          <SelectContent>
            {commodities.map((commodity) => (
              <SelectItem key={commodity} value={commodity}>
                {commodity}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Custom Commodity (if Other selected) */}
      <div className="space-y-2">
        <Label htmlFor="customCommodity">Custom Commodity (if Other selected)</Label>
        <Input id="customCommodity" name="customCommodity" placeholder="Specify your commodity" disabled={isLoading} />
      </div>

      {/* Quantity and Unit */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity *</Label>
          <Input
            id="quantity"
            name="quantity"
            type="number"
            placeholder="Enter quantity"
            required
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="unit">Unit *</Label>
          <Select name="unit" required>
            <SelectTrigger>
              <SelectValue placeholder="Select unit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MT">Metric Tons (MT)</SelectItem>
              <SelectItem value="KG">Kilograms (KG)</SelectItem>
              <SelectItem value="LBS">Pounds (LBS)</SelectItem>
              <SelectItem value="TONS">Tons</SelectItem>
              <SelectItem value="PIECES">Pieces</SelectItem>
              <SelectItem value="LITERS">Liters</SelectItem>
              <SelectItem value="GALLONS">Gallons</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Price and Price Unit */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price">Price *</Label>
          <Input
            id="price"
            name="price"
            type="number"
            step="0.01"
            placeholder="Enter price"
            required
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="priceUnit">Price Unit *</Label>
          <Select name="priceUnit" required>
            <SelectTrigger>
              <SelectValue placeholder="Select price unit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD/MT">USD per MT</SelectItem>
              <SelectItem value="USD/KG">USD per KG</SelectItem>
              <SelectItem value="USD/TON">USD per Ton</SelectItem>
              <SelectItem value="USD/PIECE">USD per Piece</SelectItem>
              <SelectItem value="USD/LITER">USD per Liter</SelectItem>
              <SelectItem value="INR/MT">INR per MT</SelectItem>
              <SelectItem value="INR/KG">INR per KG</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Location */}
      <div className="space-y-2">
        <Label htmlFor="location">Location *</Label>
        <Input id="location" name="location" placeholder="City, State, Country" required disabled={isLoading} />
      </div>

      {/* Description */}
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          placeholder="Additional details about your trade (quality specifications, delivery terms, etc.)"
          rows={4}
          disabled={isLoading}
        />
      </div>

      {/* Contact Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="contactEmail">Contact Email *</Label>
          <Input
            id="contactEmail"
            name="contactEmail"
            type="email"
            placeholder="your@email.com"
            required
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contactPhone">Contact Phone *</Label>
          <Input
            id="contactPhone"
            name="contactPhone"
            type="tel"
            placeholder="+91 9876543210"
            required
            disabled={isLoading}
          />
        </div>
      </div>

      {/* Valid Until */}
      <div className="space-y-2">
        <Label htmlFor="validUntil">Valid Until</Label>
        <Input id="validUntil" name="validUntil" type="date" disabled={isLoading} />
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p className="text-sm text-yellow-800">
          <strong>Note:</strong> All trade posts are subject to verification and approval by MASSIVE INC. We reserve the
          right to modify or remove posts that don't meet our quality standards.
        </p>
      </div>

      <Button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Posting Trade...
          </>
        ) : (
          "Post Trade"
        )}
      </Button>
    </form>
  )
}
