"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { X, Filter } from "lucide-react"

interface TradeFiltersProps {
  onFiltersChange: (filters: any) => void
}

export function TradeFilters({ onFiltersChange }: TradeFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [filters, setFilters] = useState({
    tradeType: "any",
    commodity: "any",
    location: "",
    priceMin: "",
    priceMax: "",
    quantityMin: "",
    quantityMax: "",
    postedWithin: "any",
  })

  const commodities = [
    "Iron & Steel",
    "Copper",
    "Aluminum",
    "Zinc",
    "Nickel",
    "Lead",
    "Tin",
    "Metal Scraps",
    "Chemicals",
    "Pharmaceuticals",
    "Plastic Raw Materials",
    "Paper Products",
    "Industrial Machinery",
  ]

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
    onFiltersChange(newFilters)
  }

  const clearFilters = () => {
    const emptyFilters = {
      tradeType: "any",
      commodity: "any",
      location: "",
      priceMin: "",
      priceMax: "",
      quantityMin: "",
      quantityMax: "",
      postedWithin: "any",
    }
    setFilters(emptyFilters)
    onFiltersChange(emptyFilters)
  }

  const activeFiltersCount = Object.values(filters).filter((value) => value !== "").length

  if (!isOpen) {
    return (
      <Button variant="outline" onClick={() => setIsOpen(true)} className="flex items-center bg-transparent">
        <Filter className="h-4 w-4 mr-2" />
        Filters
        {activeFiltersCount > 0 && (
          <Badge variant="secondary" className="ml-2">
            {activeFiltersCount}
          </Badge>
        )}
      </Button>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg">Filters</CardTitle>
        <div className="flex items-center space-x-2">
          {activeFiltersCount > 0 && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              Clear All
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Trade Type */}
          <div className="space-y-2">
            <Label>Trade Type</Label>
            <Select value={filters.tradeType} onValueChange={(value) => handleFilterChange("tradeType", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                <SelectItem value="buying">Buying</SelectItem>
                <SelectItem value="selling">Selling</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Commodity */}
          <div className="space-y-2">
            <Label>Commodity</Label>
            <Select value={filters.commodity} onValueChange={(value) => handleFilterChange("commodity", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                {commodities.map((commodity) => (
                  <SelectItem key={commodity} value={commodity}>
                    {commodity}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <Label>Location</Label>
            <Input
              placeholder="City, Country"
              value={filters.location}
              onChange={(e) => handleFilterChange("location", e.target.value)}
            />
          </div>

          {/* Posted Within */}
          <div className="space-y-2">
            <Label>Posted Within</Label>
            <Select value={filters.postedWithin} onValueChange={(value) => handleFilterChange("postedWithin", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Any time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any time</SelectItem>
                <SelectItem value="1h">Last hour</SelectItem>
                <SelectItem value="24h">Last 24 hours</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Price Range */}
        <div className="space-y-2">
          <Label>Price Range (USD)</Label>
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Min"
              type="number"
              value={filters.priceMin}
              onChange={(e) => handleFilterChange("priceMin", e.target.value)}
            />
            <span className="text-gray-500">to</span>
            <Input
              placeholder="Max"
              type="number"
              value={filters.priceMax}
              onChange={(e) => handleFilterChange("priceMax", e.target.value)}
            />
          </div>
        </div>

        {/* Quantity Range */}
        <div className="space-y-2">
          <Label>Quantity Range (MT)</Label>
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Min"
              type="number"
              value={filters.quantityMin}
              onChange={(e) => handleFilterChange("quantityMin", e.target.value)}
            />
            <span className="text-gray-500">to</span>
            <Input
              placeholder="Max"
              type="number"
              value={filters.quantityMax}
              onChange={(e) => handleFilterChange("quantityMax", e.target.value)}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
