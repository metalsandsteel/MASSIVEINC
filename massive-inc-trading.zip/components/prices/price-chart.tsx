"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { useMemo } from "react"

interface MetalPrice {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  high: number
  low: number
  volume: number
  lastUpdated: string
  unit: string
}

interface PriceChartProps {
  metal: MetalPrice
  timeframe: string
}

export function PriceChart({ metal, timeframe }: PriceChartProps) {
  const chartData = useMemo(() => {
    // Generate sample historical data based on current price
    const dataPoints = timeframe === "1D" ? 24 : timeframe === "1W" ? 7 : timeframe === "1M" ? 30 : 90
    const data = []

    for (let i = dataPoints; i >= 0; i--) {
      const variation = (Math.random() - 0.5) * 0.1 // 10% variation
      const price = metal.price * (1 + variation)
      const date = new Date()

      if (timeframe === "1D") {
        date.setHours(date.getHours() - i)
      } else if (timeframe === "1W") {
        date.setDate(date.getDate() - i)
      } else {
        date.setDate(date.getDate() - i)
      }

      data.push({
        time:
          timeframe === "1D"
            ? date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
            : date.toLocaleDateString(),
        price: Math.round(price * 100) / 100,
        volume: Math.floor(Math.random() * 1000) + 500,
      })
    }

    return data
  }, [metal.price, timeframe])

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" fontSize={12} tick={{ fontSize: 10 }} />
          <YAxis fontSize={12} tick={{ fontSize: 10 }} domain={["dataMin - 50", "dataMax + 50"]} />
          <Tooltip
            formatter={(value: number) => [`$${value.toLocaleString()}`, "Price"]}
            labelFormatter={(label) => `Time: ${label}`}
          />
          <Line
            type="monotone"
            dataKey="price"
            stroke={metal.changePercent >= 0 ? "#10b981" : "#ef4444"}
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
