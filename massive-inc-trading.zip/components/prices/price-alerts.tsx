"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Bell, Plus, Trash2, TrendingUp, TrendingDown } from "lucide-react"

interface MetalPrice {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  high: number
  low: number
  volume: number
  lastUpdated: string
  unit: string
}

interface PriceAlert {
  id: string
  metal: string
  condition: "above" | "below"
  targetPrice: number
  isActive: boolean
  createdAt: Date
}

interface PriceAlertsProps {
  metals: MetalPrice[]
}

export function PriceAlerts({ metals }: PriceAlertsProps) {
  const [alerts, setAlerts] = useState<PriceAlert[]>([
    {
      id: "1",
      metal: "Copper",
      condition: "above",
      targetPrice: 8500,
      isActive: true,
      createdAt: new Date(),
    },
    {
      id: "2",
      metal: "Aluminum",
      condition: "below",
      targetPrice: 2000,
      isActive: true,
      createdAt: new Date(),
    },
  ])

  const [newAlert, setNewAlert] = useState({
    metal: "",
    condition: "above" as "above" | "below",
    targetPrice: "",
  })

  const [showForm, setShowForm] = useState(false)

  const addAlert = () => {
    if (newAlert.metal && newAlert.targetPrice) {
      const alert: PriceAlert = {
        id: Date.now().toString(),
        metal: newAlert.metal,
        condition: newAlert.condition,
        targetPrice: Number.parseFloat(newAlert.targetPrice),
        isActive: true,
        createdAt: new Date(),
      }
      setAlerts([...alerts, alert])
      setNewAlert({ metal: "", condition: "above", targetPrice: "" })
      setShowForm(false)
    }
  }

  const removeAlert = (id: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
  }

  const toggleAlert = (id: string) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, isActive: !alert.isActive } : alert)))
  }

  const getTriggeredAlerts = () => {
    return alerts.filter((alert) => {
      const metal = metals.find((m) => m.name === alert.metal)
      if (!metal || !alert.isActive) return false

      return alert.condition === "above" ? metal.price >= alert.targetPrice : metal.price <= alert.targetPrice
    })
  }

  const triggeredAlerts = getTriggeredAlerts()

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Price Alerts</h2>
          <p className="text-gray-600">Set up alerts to monitor price movements</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="bg-cyan-600 hover:bg-cyan-700">
          <Plus className="h-4 w-4 mr-2" />
          New Alert
        </Button>
      </div>

      {/* Triggered Alerts */}
      {triggeredAlerts.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-red-600">Triggered Alerts</h3>
          {triggeredAlerts.map((alert) => {
            const metal = metals.find((m) => m.name === alert.metal)
            return (
              <Alert key={alert.id} className="border-red-200 bg-red-50">
                <Bell className="h-4 w-4" />
                <AlertDescription>
                  <strong>{alert.metal}</strong> is now{" "}
                  <strong>
                    {alert.condition} ${alert.targetPrice.toLocaleString()}
                  </strong>{" "}
                  (Current: ${metal?.price.toLocaleString()})
                </AlertDescription>
              </Alert>
            )
          })}
        </div>
      )}

      {/* New Alert Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Alert</CardTitle>
            <CardDescription>Get notified when a metal price reaches your target</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Metal</Label>
                <Select value={newAlert.metal} onValueChange={(value) => setNewAlert({ ...newAlert, metal: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select metal" />
                  </SelectTrigger>
                  <SelectContent>
                    {metals.map((metal) => (
                      <SelectItem key={metal.symbol} value={metal.name}>
                        {metal.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Condition</Label>
                <Select
                  value={newAlert.condition}
                  onValueChange={(value: "above" | "below") => setNewAlert({ ...newAlert, condition: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="above">Above</SelectItem>
                    <SelectItem value="below">Below</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Target Price ($)</Label>
                <Input
                  type="number"
                  placeholder="Enter price"
                  value={newAlert.targetPrice}
                  onChange={(e) => setNewAlert({ ...newAlert, targetPrice: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>&nbsp;</Label>
                <div className="flex space-x-2">
                  <Button onClick={addAlert} className="bg-cyan-600 hover:bg-cyan-700">
                    Add Alert
                  </Button>
                  <Button variant="outline" onClick={() => setShowForm(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {alerts.map((alert) => {
          const metal = metals.find((m) => m.name === alert.metal)
          const isTriggered = triggeredAlerts.some((t) => t.id === alert.id)

          return (
            <Card key={alert.id} className={isTriggered ? "border-red-200 bg-red-50" : ""}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{alert.metal}</CardTitle>
                    <CardDescription className="flex items-center space-x-1">
                      {alert.condition === "above" ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                      <span>
                        {alert.condition} ${alert.targetPrice.toLocaleString()}
                      </span>
                    </CardDescription>
                  </div>
                  <Badge variant={alert.isActive ? "default" : "secondary"}>
                    {alert.isActive ? "Active" : "Paused"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-sm text-gray-600">Current Price: ${metal?.price.toLocaleString() || "N/A"}</div>
                  <div className="text-xs text-gray-500">Created: {alert.createdAt.toLocaleDateString()}</div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={() => toggleAlert(alert.id)}>
                      {alert.isActive ? "Pause" : "Activate"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => removeAlert(alert.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {alerts.length === 0 && !showForm && (
        <Card>
          <CardContent className="text-center py-12">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts set up</h3>
            <p className="text-gray-600 mb-4">Create your first price alert to stay informed about market movements</p>
            <Button onClick={() => setShowForm(true)} className="bg-cyan-600 hover:bg-cyan-700">
              <Plus className="h-4 w-4 mr-2" />
              Create Alert
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
