"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Users, FileText, DollarSign, TrendingUp, AlertCircle, CheckCircle } from "lucide-react"

export function AdminStats() {
  const stats = [
    {
      title: "Total Users",
      value: "2,847",
      change: "+12%",
      changeType: "positive",
      icon: <Users className="h-6 w-6" />,
    },
    {
      title: "Active Trades",
      value: "156",
      change: "+8%",
      changeType: "positive",
      icon: <FileText className="h-6 w-6" />,
    },
    {
      title: "Trade Volume",
      value: "$2.4M",
      change: "+23%",
      changeType: "positive",
      icon: <DollarSign className="h-6 w-6" />,
    },
    {
      title: "Platform Growth",
      value: "18.2%",
      change: "+5%",
      changeType: "positive",
      icon: <TrendingUp className="h-6 w-6" />,
    },
  ]

  const userGrowthData = [
    { month: "Jan", users: 1200 },
    { month: "Feb", users: 1450 },
    { month: "Mar", users: 1680 },
    { month: "Apr", users: 1920 },
    { month: "May", users: 2150 },
    { month: "Jun", users: 2380 },
    { month: "Jul", users: 2650 },
    { month: "Aug", users: 2847 },
  ]

  const tradeVolumeData = [
    { month: "Jan", volume: 1.2 },
    { month: "Feb", volume: 1.5 },
    { month: "Mar", volume: 1.8 },
    { month: "Apr", volume: 2.1 },
    { month: "May", volume: 2.0 },
    { month: "Jun", volume: 2.3 },
    { month: "Jul", volume: 2.2 },
    { month: "Aug", volume: 2.4 },
  ]

  const commodityData = [
    { name: "Metals", value: 35, color: "#0891b2" },
    { name: "Steel", value: 25, color: "#8b5cf6" },
    { name: "Chemicals", value: 20, color: "#10b981" },
    { name: "Pharmaceuticals", value: 12, color: "#f59e0b" },
    { name: "Others", value: 8, color: "#ef4444" },
  ]

  const recentActivity = [
    { type: "user", message: "New user registration: Global Metals Ltd", time: "5 minutes ago", status: "pending" },
    {
      type: "trade",
      message: "Trade post approved: Copper Cathodes - 500 MT",
      time: "12 minutes ago",
      status: "approved",
    },
    { type: "user", message: "User verification completed: Steel Works Inc", time: "1 hour ago", status: "completed" },
    {
      type: "trade",
      message: "Trade post flagged for review: Aluminum Ingots",
      time: "2 hours ago",
      status: "flagged",
    },
    { type: "system", message: "LME price update completed successfully", time: "3 hours ago", status: "completed" },
  ]

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
              <div className="text-cyan-600">{stat.icon}</div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center space-x-1 mt-1">
                <Badge variant={stat.changeType === "positive" ? "default" : "destructive"} className="text-xs">
                  {stat.change}
                </Badge>
                <span className="text-xs text-gray-500">from last month</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle>User Growth</CardTitle>
            <CardDescription>Monthly user registration trends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={userGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [value, "Users"]} />
                  <Line type="monotone" dataKey="users" stroke="#0891b2" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Trade Volume Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Trade Volume</CardTitle>
            <CardDescription>Monthly trading volume in millions USD</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={tradeVolumeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value}M`, "Volume"]} />
                  <Bar dataKey="volume" fill="#0891b2" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Commodity Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Commodity Distribution</CardTitle>
            <CardDescription>Trading activity by commodity type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={commodityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {commodityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value}%`, "Share"]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {commodityData.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                    <span>{item.name}</span>
                  </div>
                  <span className="font-medium">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest platform events and actions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0">
                    {activity.status === "completed" || activity.status === "approved" ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : activity.status === "flagged" ? (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-yellow-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                  <Badge
                    variant={
                      activity.status === "completed" || activity.status === "approved"
                        ? "default"
                        : activity.status === "flagged"
                          ? "destructive"
                          : "secondary"
                    }
                    className="text-xs"
                  >
                    {activity.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
