"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Search, Filter, Eye, Check, X, Flag } from "lucide-react"

interface Trade {
  id: string
  type: "BUYING" | "SELLING"
  commodity: string
  quantity: string
  unit: string
  price: string
  priceUnit: string
  company: string
  location: string
  description: string
  status: "pending" | "approved" | "rejected" | "flagged"
  submittedBy: string
  submittedAt: string
  moderatedBy?: string
  moderatedAt?: string
  rejectionReason?: string
}

export function TradeModeration() {
  const [trades] = useState<Trade[]>([
    {
      id: "1",
      type: "BUYING",
      commodity: "Copper Cathodes",
      quantity: "500",
      unit: "MT",
      price: "8200",
      priceUnit: "USD/MT",
      company: "Global Metals Ltd",
      location: "Mumbai, India",
      description: "Looking for Grade A copper cathodes, 99.99% purity. Long-term contract preferred.",
      status: "pending",
      submittedBy: "rajesh@globalmetals.com",
      submittedAt: "2024-01-20T10:30:00Z",
    },
    {
      id: "2",
      type: "SELLING",
      commodity: "Steel Billets",
      quantity: "1000",
      unit: "MT",
      price: "650",
      priceUnit: "USD/MT",
      company: "Steel Works Inc",
      location: "Chennai, India",
      description: "High quality steel billets, ready for immediate delivery. FOB Chennai port.",
      status: "approved",
      submittedBy: "sarah@steelworks.com",
      submittedAt: "2024-01-19T14:15:00Z",
      moderatedBy: "admin@massiveinc.com",
      moderatedAt: "2024-01-19T16:20:00Z",
    },
    {
      id: "3",
      type: "BUYING",
      commodity: "Aluminum Ingots",
      quantity: "200",
      unit: "MT",
      price: "2150",
      priceUnit: "USD/MT",
      company: "Metro Trading Co",
      location: "Delhi, India",
      description: "Seeking aluminum ingots for manufacturing. Regular monthly requirement.",
      status: "flagged",
      submittedBy: "chen@metrotrading.com",
      submittedAt: "2024-01-18T09:45:00Z",
    },
    {
      id: "4",
      type: "SELLING",
      commodity: "Zinc Concentrate",
      quantity: "300",
      unit: "MT",
      price: "2800",
      priceUnit: "USD/MT",
      company: "Mining Solutions",
      location: "Kolkata, India",
      description: "Premium zinc concentrate, 55% Zn content. Direct from mine.",
      status: "rejected",
      submittedBy: "ahmed@miningsolutions.com",
      submittedAt: "2024-01-17T11:20:00Z",
      moderatedBy: "admin@massiveinc.com",
      moderatedAt: "2024-01-17T13:30:00Z",
      rejectionReason: "Insufficient documentation provided",
    },
  ])

  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null)
  const [rejectionReason, setRejectionReason] = useState("")

  const filteredTrades = trades.filter((trade) => {
    const matchesSearch =
      trade.commodity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.location.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || trade.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleTradeAction = (tradeId: string, action: "approve" | "reject" | "flag", reason?: string) => {
    console.log(`${action} trade ${tradeId}`, reason ? `Reason: ${reason}` : "")
    // In a real app, this would make an API call
    setRejectionReason("")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "pending":
        return "secondary"
      case "rejected":
        return "destructive"
      case "flagged":
        return "outline"
      default:
        return "secondary"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Trade Moderation</h2>
          <p className="text-gray-600">Review and moderate trade posts before publication</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary">{filteredTrades.length} trades</Badge>
          <Badge variant="outline">{trades.filter((t) => t.status === "pending").length} pending</Badge>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search trades by commodity, company, or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="flagged">Flagged</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Trades Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredTrades.map((trade) => (
          <Card key={trade.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant={trade.type === "BUYING" ? "default" : "secondary"}>{trade.type}</Badge>
                    <Badge variant={getStatusColor(trade.status)}>{trade.status}</Badge>
                    <span className="text-sm text-gray-500">{new Date(trade.submittedAt).toLocaleDateString()}</span>
                  </div>
                  <CardTitle className="text-xl mb-1">{trade.commodity}</CardTitle>
                  <CardDescription>
                    {trade.company} • {trade.location}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-600">Quantity</p>
                  <p className="font-semibold">
                    {trade.quantity} {trade.unit}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Price</p>
                  <p className="font-semibold text-green-600">
                    ${trade.price}/{trade.priceUnit.split("/")[1]}
                  </p>
                </div>
              </div>

              {trade.description && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600 mb-1">Description</p>
                  <p className="text-sm text-gray-800 line-clamp-2">{trade.description}</p>
                </div>
              )}

              <div className="text-xs text-gray-500 mb-4">
                <p>Submitted by: {trade.submittedBy}</p>
                {trade.moderatedBy && (
                  <p>
                    Moderated by: {trade.moderatedBy} on {new Date(trade.moderatedAt!).toLocaleDateString()}
                  </p>
                )}
                {trade.rejectionReason && <p className="text-red-600 mt-1">Reason: {trade.rejectionReason}</p>}
              </div>

              <div className="flex flex-wrap gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" onClick={() => setSelectedTrade(trade)}>
                      <Eye className="h-4 w-4 mr-1" />
                      View Details
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Trade Details</DialogTitle>
                      <DialogDescription>Complete information for this trade post</DialogDescription>
                    </DialogHeader>
                    {selectedTrade && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-gray-600">Type</label>
                            <p className="text-sm">{selectedTrade.type}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-600">Commodity</label>
                            <p className="text-sm">{selectedTrade.commodity}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-600">Quantity</label>
                            <p className="text-sm">
                              {selectedTrade.quantity} {selectedTrade.unit}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-600">Price</label>
                            <p className="text-sm">
                              ${selectedTrade.price} {selectedTrade.priceUnit}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-600">Company</label>
                            <p className="text-sm">{selectedTrade.company}</p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-600">Location</label>
                            <p className="text-sm">{selectedTrade.location}</p>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-600">Description</label>
                          <p className="text-sm mt-1">{selectedTrade.description}</p>
                        </div>
                        {selectedTrade.status === "pending" && (
                          <div className="flex space-x-2 pt-4">
                            <Button
                              onClick={() => handleTradeAction(selectedTrade.id, "approve")}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <Check className="h-4 w-4 mr-2" />
                              Approve
                            </Button>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="destructive">
                                  <X className="h-4 w-4 mr-2" />
                                  Reject
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Reject Trade</DialogTitle>
                                  <DialogDescription>Please provide a reason for rejection</DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <Textarea
                                    placeholder="Enter rejection reason..."
                                    value={rejectionReason}
                                    onChange={(e) => setRejectionReason(e.target.value)}
                                  />
                                  <div className="flex space-x-2">
                                    <Button
                                      variant="destructive"
                                      onClick={() => handleTradeAction(selectedTrade.id, "reject", rejectionReason)}
                                    >
                                      Confirm Rejection
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button variant="outline" onClick={() => handleTradeAction(selectedTrade.id, "flag")}>
                              <Flag className="h-4 w-4 mr-2" />
                              Flag for Review
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </DialogContent>
                </Dialog>

                {trade.status === "pending" && (
                  <>
                    <Button
                      size="sm"
                      onClick={() => handleTradeAction(trade.id, "approve")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleTradeAction(trade.id, "reject")}>
                      <X className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleTradeAction(trade.id, "flag")}>
                      <Flag className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
