"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Save, RefreshCw, Database, Mail, Shield, Globe } from "lucide-react"

export function SystemSettings() {
  const [settings, setSettings] = useState({
    siteName: "MASSIVE INC",
    siteDescription: "International Trading Platform",
    contactEmail: "info@massiveinc.com",
    contactPhone: "+91 (044) 1234-5678",
    autoApproveUsers: false,
    autoApproveTrades: false,
    maintenanceMode: false,
    emailNotifications: true,
    priceUpdateInterval: "30",
    maxTradeAmount: "10000000",
    supportedCurrencies: "USD,EUR,INR",
    timeZone: "Asia/Kolkata",
  })

  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)

  const handleSettingChange = (key: string, value: string | boolean) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSaving(false)
    setSaveSuccess(true)
    setTimeout(() => setSaveSuccess(false), 3000)
  }

  const handleSystemAction = (action: string) => {
    console.log(`Performing system action: ${action}`)
    // In a real app, this would make an API call
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">System Settings</h2>
          <p className="text-gray-600">Configure platform settings and system preferences</p>
        </div>
        <Button onClick={handleSave} disabled={isSaving} className="bg-cyan-600 hover:bg-cyan-700">
          {isSaving ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>

      {saveSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <AlertDescription className="text-green-800">Settings saved successfully!</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Globe className="h-5 w-5" />
              <span>General Settings</span>
            </CardTitle>
            <CardDescription>Basic platform configuration</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="siteName">Site Name</Label>
              <Input
                id="siteName"
                value={settings.siteName}
                onChange={(e) => handleSettingChange("siteName", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="siteDescription">Site Description</Label>
              <Textarea
                id="siteDescription"
                value={settings.siteDescription}
                onChange={(e) => handleSettingChange("siteDescription", e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contactEmail">Contact Email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={settings.contactEmail}
                onChange={(e) => handleSettingChange("contactEmail", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contactPhone">Contact Phone</Label>
              <Input
                id="contactPhone"
                value={settings.contactPhone}
                onChange={(e) => handleSettingChange("contactPhone", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="timeZone">Time Zone</Label>
              <Select value={settings.timeZone} onValueChange={(value) => handleSettingChange("timeZone", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Asia/Kolkata">Asia/Kolkata (IST)</SelectItem>
                  <SelectItem value="America/New_York">America/New_York (EST)</SelectItem>
                  <SelectItem value="Europe/London">Europe/London (GMT)</SelectItem>
                  <SelectItem value="Asia/Tokyo">Asia/Tokyo (JST)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Security & Moderation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span>Security & Moderation</span>
            </CardTitle>
            <CardDescription>Control user access and content moderation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-approve Users</Label>
                <p className="text-sm text-gray-500">Automatically approve new user registrations</p>
              </div>
              <Switch
                checked={settings.autoApproveUsers}
                onCheckedChange={(checked) => handleSettingChange("autoApproveUsers", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-approve Trades</Label>
                <p className="text-sm text-gray-500">Automatically approve trade posts</p>
              </div>
              <Switch
                checked={settings.autoApproveTrades}
                onCheckedChange={(checked) => handleSettingChange("autoApproveTrades", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Maintenance Mode</Label>
                <p className="text-sm text-gray-500">Put the site in maintenance mode</p>
              </div>
              <Switch
                checked={settings.maintenanceMode}
                onCheckedChange={(checked) => handleSettingChange("maintenanceMode", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email Notifications</Label>
                <p className="text-sm text-gray-500">Send email notifications to users</p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => handleSettingChange("emailNotifications", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Trading Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5" />
              <span>Trading Settings</span>
            </CardTitle>
            <CardDescription>Configure trading platform parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="priceUpdateInterval">Price Update Interval (seconds)</Label>
              <Input
                id="priceUpdateInterval"
                type="number"
                value={settings.priceUpdateInterval}
                onChange={(e) => handleSettingChange("priceUpdateInterval", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxTradeAmount">Maximum Trade Amount (USD)</Label>
              <Input
                id="maxTradeAmount"
                type="number"
                value={settings.maxTradeAmount}
                onChange={(e) => handleSettingChange("maxTradeAmount", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="supportedCurrencies">Supported Currencies</Label>
              <Input
                id="supportedCurrencies"
                value={settings.supportedCurrencies}
                onChange={(e) => handleSettingChange("supportedCurrencies", e.target.value)}
                placeholder="USD,EUR,INR"
              />
              <p className="text-xs text-gray-500">Comma-separated currency codes</p>
            </div>
          </CardContent>
        </Card>

        {/* System Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <RefreshCw className="h-5 w-5" />
              <span>System Actions</span>
            </CardTitle>
            <CardDescription>Perform system maintenance and data operations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start bg-transparent"
                onClick={() => handleSystemAction("refresh-prices")}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh LME Prices
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start bg-transparent"
                onClick={() => handleSystemAction("clear-cache")}
              >
                <Database className="h-4 w-4 mr-2" />
                Clear System Cache
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start bg-transparent"
                onClick={() => handleSystemAction("send-notifications")}
              >
                <Mail className="h-4 w-4 mr-2" />
                Send Pending Notifications
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start bg-transparent"
                onClick={() => handleSystemAction("backup-database")}
              >
                <Database className="h-4 w-4 mr-2" />
                Backup Database
              </Button>
            </div>
            <Alert>
              <AlertDescription>
                System actions may take some time to complete. Please wait for confirmation before performing another
                action.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
