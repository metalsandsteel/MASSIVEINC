"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Search, Filter, Eye, UserCheck, UserX, Mail, Phone } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  phone: string
  company: string
  country: string
  status: "active" | "pending" | "suspended"
  joinDate: string
  lastActive: string
  tradesCount: number
  verified: boolean
}

export function UserManagement() {
  const [users] = useState<User[]>([
    {
      id: "1",
      name: "Rajesh Kumar",
      email: "rajesh@globalmetals.com",
      phone: "+91 98765 43210",
      company: "Global Metals Ltd",
      country: "India",
      status: "active",
      joinDate: "2024-01-15",
      lastActive: "2024-01-20",
      tradesCount: 12,
      verified: true,
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah@steelworks.com",
      phone: "+1 555 123 4567",
      company: "Steel Works Inc",
      country: "USA",
      status: "pending",
      joinDate: "2024-01-18",
      lastActive: "2024-01-19",
      tradesCount: 0,
      verified: false,
    },
    {
      id: "3",
      name: "Chen Wei",
      email: "chen@metrotrading.com",
      phone: "+86 138 0013 8000",
      company: "Metro Trading Co",
      country: "China",
      status: "active",
      joinDate: "2024-01-10",
      lastActive: "2024-01-20",
      tradesCount: 8,
      verified: true,
    },
    {
      id: "4",
      name: "Ahmed Hassan",
      email: "ahmed@miningsolutions.com",
      phone: "+971 50 123 4567",
      company: "Mining Solutions",
      country: "UAE",
      status: "suspended",
      joinDate: "2024-01-05",
      lastActive: "2024-01-15",
      tradesCount: 3,
      verified: true,
    },
  ])

  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.company.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || user.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleUserAction = (userId: string, action: "approve" | "suspend" | "activate") => {
    console.log(`${action} user ${userId}`)
    // In a real app, this would make an API call
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">User Management</h2>
          <p className="text-gray-600">Manage user accounts and verification status</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary">{filteredUsers.length} users</Badge>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search users by name, email, or company..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>Users ({filteredUsers.length})</CardTitle>
          <CardDescription>Manage user accounts and their verification status</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Trades</TableHead>
                <TableHead>Join Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-gray-500">{user.email}</div>
                      <div className="text-sm text-gray-500">{user.country}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{user.company}</div>
                      {user.verified && (
                        <Badge variant="default" className="text-xs mt-1">
                          Verified
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        user.status === "active" ? "default" : user.status === "pending" ? "secondary" : "destructive"
                      }
                    >
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{user.tradesCount}</TableCell>
                  <TableCell>{new Date(user.joinDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => setSelectedUser(user)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>User Details</DialogTitle>
                            <DialogDescription>Complete information for {user.name}</DialogDescription>
                          </DialogHeader>
                          {selectedUser && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Name</label>
                                  <p className="text-sm">{selectedUser.name}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Company</label>
                                  <p className="text-sm">{selectedUser.company}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Email</label>
                                  <p className="text-sm flex items-center">
                                    <Mail className="h-4 w-4 mr-1" />
                                    {selectedUser.email}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Phone</label>
                                  <p className="text-sm flex items-center">
                                    <Phone className="h-4 w-4 mr-1" />
                                    {selectedUser.phone}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Country</label>
                                  <p className="text-sm">{selectedUser.country}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Status</label>
                                  <Badge
                                    variant={
                                      selectedUser.status === "active"
                                        ? "default"
                                        : selectedUser.status === "pending"
                                          ? "secondary"
                                          : "destructive"
                                    }
                                  >
                                    {selectedUser.status}
                                  </Badge>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Join Date</label>
                                  <p className="text-sm">{new Date(selectedUser.joinDate).toLocaleDateString()}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-gray-600">Last Active</label>
                                  <p className="text-sm">{new Date(selectedUser.lastActive).toLocaleDateString()}</p>
                                </div>
                              </div>
                              <div className="flex space-x-2 pt-4">
                                {selectedUser.status === "pending" && (
                                  <Button
                                    onClick={() => handleUserAction(selectedUser.id, "approve")}
                                    className="bg-green-600 hover:bg-green-700"
                                  >
                                    <UserCheck className="h-4 w-4 mr-2" />
                                    Approve User
                                  </Button>
                                )}
                                {selectedUser.status === "active" && (
                                  <Button
                                    variant="destructive"
                                    onClick={() => handleUserAction(selectedUser.id, "suspend")}
                                  >
                                    <UserX className="h-4 w-4 mr-2" />
                                    Suspend User
                                  </Button>
                                )}
                                {selectedUser.status === "suspended" && (
                                  <Button
                                    onClick={() => handleUserAction(selectedUser.id, "activate")}
                                    className="bg-green-600 hover:bg-green-700"
                                  >
                                    <UserCheck className="h-4 w-4 mr-2" />
                                    Reactivate User
                                  </Button>
                                )}
                              </div>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>

                      {user.status === "pending" && (
                        <Button
                          size="sm"
                          onClick={() => handleUserAction(user.id, "approve")}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <UserCheck className="h-4 w-4" />
                        </Button>
                      )}
                      {user.status === "active" && (
                        <Button size="sm" variant="destructive" onClick={() => handleUserAction(user.id, "suspend")}>
                          <UserX className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
